<html>
<head>
</head>
<body>
<form method="post" action="home.php">
<fieldset>
<table border='1' >

<tr >
     <td colspan="2"> <h1 align="center" > person profile </h1> </td>
	 
</tr>

 <tr>
	<td>Name: </td>
	<td> <input type="text" name="uname"> </td>
	</tr>
	
	<tr>
	<td>Email: </td>
	<td> <input type="text" name="mail"> </td>
	</tr>
 

	<tr>
	<td>Gender </td>
	<td> 
	<input type="radio" name="gender" value="male" >male 
	<input type="radio" name="gender" value="female">female 
	<input type="radio" name="gender" value="other">other 
	</td>
	</tr>
	
	
   	<tr>
	<td>Date of birth: </td>
	<td> 
	<input type="text" name="bdate1"  > /
	<input type="text" name="bdate2" > /
	<input type="text" name="bdate3" > (dd/mm/yyyy)
	</td>
	</tr>
	
	
	
	<tr>
	<td>Blood Grouop </td>
	<td> 
	 <select name="blood group">
	 <option value="A"> A </option>
	  <option value="A+"> A+ </option>
	   <option value="0+"> O+ </option>
	 </select>
	</td>
	
	</tr>

<tr>
	<td>Degree </td>
	<td> 
	<input type="checkbox" name="degree[]" value="SSC"> SSC
	<input type="checkbox" name="degree[]" value="HSC"> HSC
	<input type="checkbox" name="degree[]" value="Bsc"> Bsc.
	<input type="checkbox" name="degree[]" value=" Msc"> Msc.
	</td>
	
	</tr>

<tr>
	<td>Picture  </td>
	<td> 
	<input type="file"  name="img" accept="image/*" >
	</td>
	
	</tr>
   <tr>
	<td colspan="2"> </td>

	</tr>

<tr>
	<td> </td>
	<td> 
	<input type="submit" name="submit" value="submit">
	<input type="reset" name="reset"> 
	</td>
	
	</tr>



















</table>
</fieldset>
</form>
</body>
</html>