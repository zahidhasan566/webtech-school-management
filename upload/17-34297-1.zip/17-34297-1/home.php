<?php

if(isset($_REQUEST['submit']))
{
	$name=trim($_REQUEST['uname']);
	$email=trim($_REQUEST['mail']);
	$gen=$_REQUEST['gender'];
	$dob1=$_REQUEST['bdate1'];
	$dob2=$_REQUEST['bdate2'];
	$dob3=$_REQUEST['bdate3'];
	$blood=$_REQUEST['blood'];
	$deg=$_REQUEST['degree'];
    $image=$_REQUEST['img'];
	
	
	$len=strlen($name);
	
	$pattern="/^[a-zA-Z.-]+$/";
	$pattern2="/^[a-z]+(@)+[a-z]+(.com)$/";
	$pattern3="/[0-31]+$/";
	$pattern4="/[1-12]+$/";
	$pattern5="/[1900-2016]+$/";
	
	
	 if($name=="" || $len <2 )
	{
		echo "name is required";
	}
	 else if(!preg_match($pattern,$name))
	{
		echo "name is not  matched";
	}
	
	else if ($email=="")
		{
			echo "email is required";
		}
		
			 else if(!preg_match($pattern2,$email))
	{
		echo "mail is not  matched";
	}
	else if ($gen=="")
		{
			echo "gender is required";
		}
		
		
		else if ($deg=="")
		{
			echo "degree is required";
		}
		
		else if ($dob1=="" || $dob2=="" || $dob3=="")
		{
			echo "dob is required";
		}
		
		else if (!preg_match($pattern3,$dob1) || !preg_match($pattern4,$dob2) || !preg_match($pattern3,$dob1))
		{
			echo "invalid date of birth";
		}
		
		
}
else {
	header('location:form.php');
}











?>